const express = require("express");
const MongoClient = require("mongodb").MongoClient;
const { ObjectID } = require("mongodb");
const client = new MongoClient(
  "mongodb+srv://Mara:Mara000@cluster0.2rfqw.mongodb.net/myFirstDatabase",
  { useNewUrlParser: true, useUnifiedTopology: true }
);
let db;

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use((req, res, next) => {
  if (!db) {
    client.connect(function (err) {
      db = client.db("mydatabase");
      req.db = db.collection("myzipcode");
      next();
    });
  } else {
    req.db = db.collection("myzipcode");
    next();
  }
});

app.get("/", (req, res) => {
  req.db
    .find({})
    .project({_id: 0 })
    .sort({zipcode:1})
    .toArray()
    .then((doc) => res.json({ status: "success", result: doc }))
    .catch((err) => res.json({ status: "fail" }));
});
app.get("/:id", (req, res) => {
  req.db
    .findOne({ _id: ObjectID(req.params.id) })
    .then((doc) => res.json({ status: "success", result: doc }))
    .catch((err) => res.json({ status: "fail" }));
});

app.delete("/:id", (req, res) => {
  req.db
    .deleteOne({ _id: ObjectID(req.params.id) })
    .then((doc) => res.json({ status: "success" }))
    .catch((err) => res.json({ status: "fail" }));
});

app.post("/", async (req, res) => {
  await req.db.insertOne(req.body, (err, results) =>
    res.json({ status: "success", result: results })
  );
});

app.use(function (err, req, res, next) {
  res.status(err.status || 500);
  res.json({
    message: err.message,
    error: {},
  });
});

app.listen(3000, () => console.log("listening to 3000"));
